testing with gpt
